import{l as a}from"./index-DARGWBSx.js";const t=async()=>{try{return(await a.get("/manufacturers/all")).data.data||[]}catch(t){return[]}};export{t as g};
