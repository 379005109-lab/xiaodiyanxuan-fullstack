import{l as a}from"./index-DARGWBSx.js";const t=async()=>(await a.get("/site-config")).data.data,s=async t=>(await a.post("/site-config/batch",{configs:t})).data;export{s as b,t as g};
